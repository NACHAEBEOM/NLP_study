# Chatbot_data.          
Chatbot_data_for_Korean v1.0             


## Data description.     

1. 챗봇 트레이닝용 문답 페어 11,876개           
2. 일상다반서 0, 이별(부정) 1, 사랑(긍정) 2로 레이블링                
                      
                     
## Quick peek.                
                                     
![quick_peek](./data.png)


